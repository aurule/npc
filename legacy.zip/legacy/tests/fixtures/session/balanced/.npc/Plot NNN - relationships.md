# Plot NNN Relationships
