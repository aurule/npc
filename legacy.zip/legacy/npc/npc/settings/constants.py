"""
Constants for the Settings module
"""

VALID_EXTENSIONS = ['.json', '.yaml']
"""list: file extensions that can contain settings"""
