"""Current version string for NPC"""

__version__ = "1.4.2 dev"
