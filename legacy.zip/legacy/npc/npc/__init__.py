"""
Package for reading and manipulating campaign information.
"""

from . import commands, settings, character, cli, __version__
