Played: 

# (in-game date and time)
